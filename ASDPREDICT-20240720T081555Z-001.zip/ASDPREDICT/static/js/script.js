window.onscroll = function () {
    scrollFunction();
  };
  function scrollFunction() {
    document.getElementById("navbar").style.background = "#fff";
  }
  
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelectorAll(".nav__link");
  if (navToggle) {
    navToggle.addEventListener("click", () => {
      document.body.classList.toggle("nav-open");
    });
  }else{
    console.error("No element with class 'nav-toggle' found.");
  }
  
  navLinks.forEach((link) => {
    link.addEventListener("click", () => {
      document.body.classList.remove("nav-open");
    });
  });

  document.addEventListener("DOMContentLoaded", function () {
    const sliderContainer = document.querySelector('.slider-container');
    let currentIndex = 0;

    function nextSlide() {
        currentIndex = (currentIndex + 1) % document.querySelectorAll('.slide').length;
        updateSlider();
    }

    function updateSlider() {
        const newTransformValue = -currentIndex * 100 + 'vw';
        sliderContainer.style.transform = 'translateX(' + newTransformValue + ')';
    }

    
    setInterval(nextSlide, 1500);
});


// var selectDropdowns = document.querySelectorAll('.select-dropdown');
// selectDropdowns.forEach(function(selectDropdown) {
//     selectDropdown.addEventListener('change', function() {
//         var selectedOption = this.value; // Get the selected option value
//         var inputValue = selectedOption === 'Sometimes' || selectedOption === 'Rarely' || selectedOption === 'Never' ? 1 : 0;
//         console.log('Input value:', inputValue); // Output the assigned value (you can replace this with your desired logic)
//     });
// });

// document.getElementById('A10').addEventListener('change', function() {
//   var selectedOption = this.value; 
//   var inputValue = selectedOption === 'Sometimes' || selectedOption === 'Rarely' || selectedOption === 'Never' ? 0 : 1;
//   console.log('Input value:', inputValue); 
// });

// document.getElementById('sex').addEventListener('change', function() {
//   var selectedOption = this.value; 
//   var inputValue = selectedOption === 'Male' ? 0 : 1;
//   console.log('Input value:', inputValue); 
// });

document.getElementById("survey-form").addEventListener("submit", function(event) {
  event.preventDefault(); // Prevent default form submission

  // Serialize form data into JSON object
  var formData = {
      case: document.getElementById("case").value,
      a1: document.getElementById("A1").value,
      a2: document.getElementById("A2").value,
      a3: document.getElementById("A3").value,
      a4: document.getElementById("A4").value,
      a5: document.getElementById("A5").value,
      a6: document.getElementById("A6").value,
      a7: document.getElementById("A7").value,
      a9: document.getElementById("A9").value,
      a10: document.getElementById("A10").value,
      age: document.getElementById("age").value,
      qscore: document.getElementById("qscore").value,
      sex: document.getElementById("sex").value,
  };

  const form = document.getElementById('survey-form');
            
            // Serialize form data using FormData API
           // const formData = new FormData(form);
            
            // Convert serialized form data to JSON object
            const jsonObject = {};
            formData.forEach(function(value, key) {
                jsonObject[key] = value;
            });
            
            // Convert JSON object to JSON string
            const jsonData = JSON.stringify(jsonObject);
            
            // Log JSON data to console (for demonstration)
            console.log(jsonData);

  // Send form data to Flask backend
  fetch("/predict", {
      method: "POST",
      headers: {
          "Content-Type": "application/json"
      },
      body: JSON.stringify(formData)
  })
  .then(response => response.json())
  .then(data => {
  })
  .catch(error => {
      console.error("Error:", error);
  });
});